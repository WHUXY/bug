lighttpd for Debian
-------------------

<possible notes regarding this package - if none, delete this file>

 -- Vincent Wagelaar <vincent@hannibal.lr-s.tudelft.nl>, Wed, 24 Mar 2004 08:20:58 +0100
