#define TK_CRLF                            1
#define TK_STRING                          2
#define TK_COLON                           3
